<!DOCTYPE HTML>
<html>
<head>
  <title>ESP32 WITH MYSQL DATABASE</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    /* Your existing styles */
    html {font-family: Arial; display: inline-block; text-align: center;}
    p {font-size: 1.2rem;}
    h4 {font-size: 0.8rem;}
    body {margin: 0;}
    .topnav {overflow: hidden; background-color: #0c6980; color: white; font-size: 1.2rem;}
    .styled-table {
      border-collapse: collapse;
      margin-left: auto; 
      margin-right: auto;
      font-size: 0.9em;
      font-family: sans-serif;
      min-width: 400px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
      border-radius: 0.5em;
      overflow: hidden;
      width: 90%;
    }
    .styled-table thead tr {
      background-color: #0c6980;
      color: #ffffff;
      text-align: left;
    }
    .styled-table th {
      padding: 12px 15px;
      text-align: left;
    }
    .styled-table td {
      padding: 12px 15px;
      text-align: left;
    }
    .styled-table tbody tr:nth-of-type(even) {
      background-color: #f3f3f3;
    }
    .styled-table tbody tr.active-row {
      font-weight: bold;
      color: #009879;
    }
    .bdr {
      border-right: 1px solid #e3e3e3;
      border-left: 1px solid #e3e3e3;
    }
    td:hover {background-color: rgba(12, 105, 128, 0.21);}
    tr:hover {background-color: rgba(12, 105, 128, 0.15);}
    .styled-table tbody tr:nth-of-type(even):hover {background-color: rgba(12, 105, 128, 0.15);}
    .btn-group .button {
      background-color: #0c6980; /* Green */
      border: 1px solid #e3e3e3;
      color: white;
      padding: 5px 8px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 14px;
      cursor: pointer;
      float: center;
    }
    .btn-group .button:not(:last-child) {
      border-right: none; /* Prevent double borders */
    }
    .btn-group .button:hover {
      background-color: #094c5d;
    }
    .btn-group .button:active {
      background-color: #0c6980;
      transform: translateY(1px);
    }
    .btn-group .button:disabled,
    .button.disabled{
      color:#fff;
      background-color: #a0a0a0; 
      cursor: not-allowed;
      pointer-events:none;
    }
  </style>
</head>

<body>
  <div class="topnav">
    <h3>Temperature And Humidity Sensor Graph</h3>
  </div>

  <br>

  <!-- Canvas for Chart.js -->
  <canvas id="myChart" width="400" height="200"></canvas>

  <br>

  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script>
    window.onload = function() {
      fetchDataForChart();
    };

    function fetchDataForChart() {
      fetch('fetch_data.php')
        .then(response => response.json())
        .then(data => {
          var ctx = document.getElementById('myChart').getContext('2d');
          var myChart = new Chart(ctx, {
            type: 'line',
            data: {
              labels: data.labels,
              datasets: [{
                label: 'Temperature (°C)',
                data: data.temperatures,
                borderColor: 'rgba(255, 99, 132, 1)',
                borderWidth: 1,
                fill: false
              }, {
                label: 'Humidity (%)',
                data: data.humidities,
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1,
                fill: false
              }]
            },
            options: {
              scales: {
                x: {
                  beginAtZero: true
                },
                y: {
                  beginAtZero: true
                }
              }
            }
          });
        })
        .catch(error => console.error('Error fetching data:', error));
    }
  </script>
</body>
</html>
