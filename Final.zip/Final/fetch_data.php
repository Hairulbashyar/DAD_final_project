<?php
include 'database.php';

$pdo = Database::connect();
$sql = 'SELECT * FROM esp32_table_dht22_leds_record ORDER BY time, date';
$result = $pdo->query($sql);

$labels = [];
$temperatures = [];
$humidities = [];

foreach ($result as $row) {
    $labels[] = $row['time'];
    $temperatures[] = $row['temperature'];
    $humidities[] = $row['humidity'];
}

Database::disconnect();

echo json_encode([
    'labels' => $labels,
    'temperatures' => $temperatures,
    'humidities' => $humidities,
]);
?>
